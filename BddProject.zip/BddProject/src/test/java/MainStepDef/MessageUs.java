package MainStepDef;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import POM.ConfirmationPage;
import POM.contactUs;
import POM.homePage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MessageUs {
	WebDriver driver = new ChromeDriver();
	@Given("User is on the Pairview homepage")
	public void user_is_on_the_pairview_homepage() {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(25, TimeUnit.SECONDS);
		driver.navigate().to("https://www.pairviewtraining.com/");

	}

	//When the user is on the home page & clicks on contact us link

	homePage HomePage = new homePage(driver);
	@When("User clicks on the Contact Us link")
	public void user_clicks_on_the_contact_us_link() {
		HomePage.user_clicks_on_the_contact_us_link();
	}


	// When the user fills the contact us form
	contactUs ContactUs = new contactUs(driver);

	@When("the user inputs their first name")
	public void InputeFirstName() {
		ContactUs.InputeFirstName();
	};

	@And("the user inputs their last name")
	public void InputLastName() {
		ContactUs.InputeLastName();
	};
    @And ("the user inputs their email")
	public void InputeEmail() {
		ContactUs.InputeEmail();
	};	
	@And ("the user inputs their phone number")
	public void InputeNumber() {
		ContactUs.InputeNumber();
	};
	@And ("the user inputs their position")
	public void InputePosition() {
		ContactUs.InputePosition();
	};	
	@And ("the user selects a program")
	public void InputeSelection() {
		ContactUs.InputeSelection();

	};

	@When("User submits the form")
	public void Submit() {
		ContactUs.Submit();
		
	};

	//When the user is able to notice confirmation page
	ConfirmationPage confirmationPage = new ConfirmationPage(driver);
			
	@Then("User should see a confirmation message")
	public void ConfirmationMessage() {
		confirmationPage.ConfirmationMessage();

	};

}
