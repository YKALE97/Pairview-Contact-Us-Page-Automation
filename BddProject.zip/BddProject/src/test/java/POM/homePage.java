package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.When;

public class homePage {WebDriver driver= null;


public homePage(WebDriver driver) {
	this.driver= driver;
}

public void user_clicks_on_the_contact_us_link() {
	driver.findElement(By.xpath("//*[@id=\"how-we-work\"]/div")).click();
	driver.findElement(By.xpath("//a[@id='sub-item--contact-us']//div[@class='MuiBox-root css-142sxpm']")).click();
    
}
}