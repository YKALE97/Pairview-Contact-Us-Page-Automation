package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;

public class contactUs {
	WebDriver driver= null;

public contactUs(WebDriver driver) {
	this.driver= driver;
}



public void InputeFirstName() {
	driver.findElement(By.id("mui-6")).sendKeys("Yogesh");
}
 public void InputeLastName() {
	driver.findElement(By.id("mui-7")).sendKeys("Kale");
}	

 public void InputeEmail() {
	 driver.findElement(By.id("mui-8")).sendKeys("Yogeshkale747@gmail.com");
	}	

 public void InputeNumber() {
	 driver.findElement(By.id("mui-9")).sendKeys("07861271215");
	}	
	
 public void InputePosition() {
	 driver.findElement(By.id("mui-10")).sendKeys("QA Tester");
	}	

 public void InputeSelection() {
	 Select dropdown=  new Select(driver.findElement(By.xpath("//*[@id=\"program\"]")));
		dropdown.selectByVisibleText("AI Engineer");
		//dropdown.findElement(By.cssSelector("option[value='AI Engineer']"));
//driver.findElement(By.id("program")).click();

//driver.findElement(By.id("mui-11")).sendKeys("Give me details about software automation testing course ");
//List<WebElement> checkboxes = driver.findElements(By.className("PrivateSwitchBase-input css-1m9pwf3"));
//checkboxes.get(1).click();
	}
 
 
	public void Submit() {
		driver.findElement(By.id("mui-24")).click();
	    
	}
    
}

