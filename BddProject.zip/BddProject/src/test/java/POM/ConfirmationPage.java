package POM;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Then;


public class ConfirmationPage {WebDriver driver= null;
public ConfirmationPage(WebDriver driver) {
	this.driver= driver;

}
public void ConfirmationMessage() {
	driver.getPageSource().contains("WE ARE HERE");

};

}